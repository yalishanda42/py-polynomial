"""Package handling mathematical single-variable polynomials."""

__all__ = ("Polynomial",
           "Trinomial",
           "Binomial")
